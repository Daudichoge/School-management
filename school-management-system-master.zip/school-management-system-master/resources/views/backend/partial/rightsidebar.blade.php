<script>
    window.frontendWebsite = {{$frontend_website}};
    window.show_language = {{$show_language}};
</script>
<!-- Control Sidebar -->
<aside  class="control-sidebar control-sidebar-dark">
    <div id="rightSideBarContent">

    </div>
  </aside>
  <!-- /.control-sidebar -->
  <!-- Add the sidebar's background. This div must be placed
       immediately after the control sidebar -->
  <div class="control-sidebar-bg"></div>